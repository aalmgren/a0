import React from 'react';
import { View, Text } from 'react-native';

const ReplenishmentScreen = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Replenishment Module</Text>
    </View>
  );
};

export default ReplenishmentScreen;
